import { Router } from "express";
import multer from "multer";
import fs from "fs";

const router = Router();
const storage = multer.diskStorage({
    destination: "./files",
    filename: (req, file, cb) => {
        const date = new Date();
        cb(null, String(date) + file.originalname);
    }
});
const upload = multer({ storage: storage });

router.route("/upload").post(upload.array("files",10), (req, res) => {
    try {
        let files = req.files;
        fs.readFile("./files.json", "utf-8", (error, data) => {
            data = data ? JSON.parse(data) : [];
            files.forEach(file => {
                data.push(file)
            });
            fs.writeFile("./files.json", JSON.stringify(data), error => {
                if (error) {
                    console.log(error);
                    return res.status(500).send("Error occured!")
                }
                return res.json("Files uploaded!");
            })
        })
    } catch (error) {
        console.log(error);
        res.status(500).send("Error")
    }
})

export default router;
